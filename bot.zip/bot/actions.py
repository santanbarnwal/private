# This files contains your custom actions which can be used to run
# custom Python code.
#
# See this guide on how to implement these action:
# https://rasa.com/docs/rasa/core/actions/#custom-actions/


# This is a simple example for a custom action which utters "Hello World!"

from typing import Any, Text, Dict, List

from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher

from rasa_sdk.forms import FormAction

class ActionHelloWorld(Action):

    def name(self) -> Text:
        return "action_hello_world"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:


        dispatcher.utter_message(text="Hello World!")

        return []

class Action_Enter_Website(Action):
    def name(self) -> Text:
        return "action_enter_website"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:


        dispatcher.utter_message(text="Hello World!")

        return []


class DetailForm(FormAction):
    """Custom form action to fill all slots required to find specific type
    of healthcare facilities in a certain city or zip code."""

    def name(self) -> Text:
        """Unique identifier of the form"""

        return "detail_form"

    @staticmethod
    def required_slots(tracker: Tracker) -> List[Text]:
        """A list of required slots that the form has to fill"""

        return ["~~username~~", "~~password~~"]


    def slot_mappings(self):
        # type: () -> Dict[Text: Union[Dict, List[Dict]]]
        """A dictionary to map required slots to
            - an extracted entity
            - intent: value pairs
            - a whole message
            or a list of them, where a first match will be picked"""

        return {"~~username~~": [self.from_text()], "~~password~~": [self.from_text()]}


    def submit(self,
               dispatcher: CollectingDispatcher,
               tracker: Tracker,
               domain: Dict[Text, Any]
               ) -> List[Dict]:
        """Once required slots are filled, print buttons for found facilities"""

        
        # TODO: update rasa core version for configurable `button_type`
        dispatcher.utter_message("Completed ")
        f1=open('D:\\Rasa\\bot\\runtime\\test_login.py','r').read()
        f2=open('D:\\Rasa\\bot\\test_login.py','w')
        m=f1.replace('##username##',tracker.get_slot("~~username~~"))
        m=m.replace('##password##',tracker.get_slot("~~password~~"))
        f2.write(m) 
 
        exec(open("D:\\Rasa\\bot\\test_login.py").read())
        import webbrowser
        webbrowser.open("file.txt")
        dispatcher.utter_message("Completed ")

        return []

